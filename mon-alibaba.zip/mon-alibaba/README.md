# Mon Alibaba – Phase 1 (fondations)

Next.js 15 + TypeScript + Tailwind + Supabase. Non testé : lancez `npm run lint` et `npm run build`, puis signalez les erreurs.

## Installation
1. Supabase : créez un projet, exécutez `supabase/001_fondations.sql` dans SQL Editor.
2. Supabase > Authentication > Providers > Email : mettez la longueur minimale du mot de passe à 8.
3. `npm install`
4. Copiez `.env.example` en `.env.local` et renseignez l'URL et la clé **anon** (Project Settings > API).
5. `npm run dev` puis ouvrez http://localhost:3000

## Déploiement Vercel
1. Poussez le dossier sur GitHub, puis Vercel > Add New > Project > importez le dépôt.
2. Ajoutez les deux variables d'environnement de `.env.example`.
3. Supabase > Authentication > URL Configuration : Site URL = votre domaine Vercel ;
   Redirect URLs = `https://VOTRE-DOMAINE/auth/callback`.

## Phase 1 : inclus
Inscription, connexion, déconnexion, session sécurisée (cookies), rôles lus depuis la base,
français/anglais, sélecteur de devise (devises de la base), catégories lues depuis la base.

## Pas encore fait
Réinitialisation du mot de passe, photo de profil, recherche, fiches produits, boutiques,
panier, commandes, messagerie, paiements, livraison, administration (Phases 2 à 6).
