import { cookies } from 'next/headers'
import type { Lang } from './i18n'

export async function getPrefs(): Promise<{ lang: Lang; cur: string }> {
  const c = await cookies()
  const lang: Lang = c.get('lang')?.value === 'en' ? 'en' : 'fr'
  const cur = (c.get('cur')?.value ?? 'USD').toUpperCase()
  return { lang, cur }
}
