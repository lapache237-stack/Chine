export type Lang = 'fr' | 'en'

const fr = {
  tagline: 'Le commerce sans frontières',
  intro: 'La marketplace internationale qui relie acheteurs et fournisseurs.',
  categories: 'Catégories',
  noCategories: 'Aucune catégorie. Exécutez le script SQL de la base de données.',
  login: 'Connexion',
  register: 'Inscription',
  logout: 'Déconnexion',
  hello: 'Bonjour',
  email: 'Adresse e-mail',
  password: 'Mot de passe (8 caractères min.)',
  name: 'Nom complet',
  createAccount: 'Créer mon compte',
  badLogin: 'E-mail ou mot de passe incorrect.',
  checkEmail: 'Compte créé. Vérifiez votre boîte e-mail pour confirmer votre adresse.',
  noAccount: 'Pas de compte ?',
  haveAccount: 'Déjà un compte ?',
  wait: 'Veuillez patienter…',
  roles: { buyer: 'Acheteur', seller: 'Vendeur', admin: 'Administrateur' },
}
export type Dict = typeof fr
const en: Dict = {
  tagline: 'Commerce without borders',
  intro: 'The international marketplace connecting buyers and suppliers.',
  categories: 'Categories',
  noCategories: 'No categories. Run the database SQL script.',
  login: 'Log in',
  register: 'Sign up',
  logout: 'Log out',
  hello: 'Hello',
  email: 'Email address',
  password: 'Password (8 characters min.)',
  name: 'Full name',
  createAccount: 'Create my account',
  badLogin: 'Incorrect email or password.',
  checkEmail: 'Account created. Check your inbox to confirm your email address.',
  noAccount: 'No account yet?',
  haveAccount: 'Already have an account?',
  wait: 'Please wait…',
  roles: { buyer: 'Buyer', seller: 'Seller', admin: 'Administrator' },
}
export const dict: Record<Lang, Dict> = { fr, en }
