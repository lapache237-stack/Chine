export type Rate = { base: string; quote: string; rate: number }

// Convertit un montant avec les taux de la table exchange_rates.
// Renvoie null si aucun taux n'est disponible (on affiche alors la devise d'origine).
export function convert(amount: number, from: string, to: string, rates: Rate[]): number | null {
  if (from === to) return amount
  const direct = rates.find((r) => r.base === from && r.quote === to)
  if (direct) return amount * Number(direct.rate)
  const inverse = rates.find((r) => r.base === to && r.quote === from)
  if (inverse) return amount / Number(inverse.rate)
  return null
}

export function formatMoney(amount: number, currency: string, lang: string): string {
  try {
    return new Intl.NumberFormat(lang === 'en' ? 'en-US' : 'fr-FR', { style: 'currency', currency }).format(amount)
  } catch {
    return `${amount.toFixed(2)} ${currency}`
  }
}
