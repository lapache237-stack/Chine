'use client'
import { useRouter } from 'next/navigation'

export default function Switcher({ lang, cur, currencies }: { lang: string; cur: string; currencies: string[] }) {
  const router = useRouter()
  function set(key: string, value: string) {
    document.cookie = `${key}=${value}; path=/; max-age=31536000; samesite=lax`
    router.refresh()
  }
  const cls = 'rounded bg-white/10 px-2 py-1 text-sm text-white'
  return (
    <div className="flex gap-2">
      <select className={cls} value={lang} onChange={(e) => set('lang', e.target.value)} aria-label="Language">
        <option className="text-black" value="fr">FR</option>
        <option className="text-black" value="en">EN</option>
      </select>
      {currencies.length > 0 && (
        <select className={cls} value={cur} onChange={(e) => set('cur', e.target.value)} aria-label="Currency">
          {currencies.map((c) => (
            <option className="text-black" key={c} value={c}>{c}</option>
          ))}
        </select>
      )}
    </div>
  )
}
