import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { getPrefs } from '@/lib/prefs'
import { dict } from '@/lib/i18n'
import Switcher from './Switcher'

export default async function Header() {
  const { lang, cur } = await getPrefs()
  const t = dict[lang]
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const { data: profile } = user
    ? await supabase.from('profiles').select('full_name, role').eq('id', user.id).single()
    : { data: null }
  const { data: cs } = await supabase.from('currencies').select('code').eq('active', true).order('code')

  return (
    <header className="bg-navy text-white">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3">
        <Link href="/" className="text-xl font-extrabold">
          Mon <span className="text-brand">Alibaba</span>
        </Link>
        <div className="flex flex-wrap items-center gap-3">
          <Switcher lang={lang} cur={cur} currencies={(cs ?? []).map((c: { code: string }) => c.code)} />
          {user ? (
            <>
              <span className="text-sm">
                {t.hello} {profile?.full_name || user.email}
                {profile?.role ? ` · ${t.roles[profile.role as keyof typeof t.roles]}` : ''}
              </span>
              <form action="/auth/signout" method="post">
                <button className="rounded border border-white/40 px-3 py-1 text-sm">{t.logout}</button>
              </form>
            </>
          ) : (
            <>
              <Link href="/login" className="text-sm">{t.login}</Link>
              <Link href="/register" className="rounded bg-brand px-3 py-1 text-sm font-semibold">{t.register}</Link>
            </>
          )}
        </div>
      </div>
    </header>
  )
}
