'use client'
import { useState, type FormEvent } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'
import type { Dict } from '@/lib/i18n'

export default function AuthForm({ mode, t }: { mode: 'login' | 'register'; t: Dict }) {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const [busy, setBusy] = useState(false)

  async function submit(e: FormEvent) {
    e.preventDefault()
    setBusy(true)
    setMsg(null)
    const supabase = createClient()
    if (mode === 'login') {
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) setMsg({ ok: false, text: t.badLogin })
      else { router.push('/'); router.refresh() }
    } else {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { full_name: name }, emailRedirectTo: `${location.origin}/auth/callback` },
      })
      if (error) setMsg({ ok: false, text: error.message })
      else if (data.session) { router.push('/'); router.refresh() }
      else setMsg({ ok: true, text: t.checkEmail })
    }
    setBusy(false)
  }

  const input = 'w-full rounded border border-gray-300 bg-white px-3 py-2'
  return (
    <form onSubmit={submit} className="mx-auto max-w-sm space-y-3 rounded-xl border bg-white p-6">
      <h1 className="text-xl font-bold">{mode === 'login' ? t.login : t.register}</h1>
      {mode === 'register' && (
        <input className={input} placeholder={t.name} value={name} onChange={(e) => setName(e.target.value)} required />
      )}
      <input className={input} type="email" placeholder={t.email} value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" />
      <input className={input} type="password" placeholder={t.password} value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} />
      {msg && <p className={msg.ok ? 'text-sm text-green-700' : 'text-sm text-red-600'}>{msg.text}</p>}
      <button disabled={busy} className="w-full rounded bg-brand py-2 font-semibold text-white disabled:opacity-60">
        {busy ? t.wait : mode === 'login' ? t.login : t.createAccount}
      </button>
      <p className="text-center text-sm">
        {mode === 'login' ? t.noAccount : t.haveAccount}{' '}
        <Link className="font-semibold text-brand" href={mode === 'login' ? '/register' : '/login'}>
          {mode === 'login' ? t.register : t.login}
        </Link>
      </p>
    </form>
  )
}
