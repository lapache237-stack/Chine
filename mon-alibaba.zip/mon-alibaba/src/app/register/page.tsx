import AuthForm from '@/components/AuthForm'
import { getPrefs } from '@/lib/prefs'
import { dict } from '@/lib/i18n'

export default async function RegisterPage() {
  const { lang } = await getPrefs()
  return <AuthForm mode="register" t={dict[lang]} />
}
