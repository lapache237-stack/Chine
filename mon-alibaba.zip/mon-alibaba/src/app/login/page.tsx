import AuthForm from '@/components/AuthForm'
import { getPrefs } from '@/lib/prefs'
import { dict } from '@/lib/i18n'

export default async function LoginPage() {
  const { lang } = await getPrefs()
  return <AuthForm mode="login" t={dict[lang]} />
}
