import { createClient } from '@/lib/supabase/server'
import { getPrefs } from '@/lib/prefs'
import { dict } from '@/lib/i18n'

type Category = { id: number; slug: string; name_fr: string; name_en: string }

export default async function Home() {
  const { lang } = await getPrefs()
  const t = dict[lang]
  const supabase = await createClient()
  const { data } = await supabase.from('categories').select('id, slug, name_fr, name_en').order('position')
  const categories = (data ?? []) as Category[]

  return (
    <div className="space-y-8">
      <section className="rounded-2xl bg-navy p-8 text-white">
        <h1 className="text-3xl font-extrabold">{t.tagline}</h1>
        <p className="mt-2 max-w-xl opacity-90">{t.intro}</p>
      </section>
      <section>
        <h2 className="mb-3 text-xl font-bold">{t.categories}</h2>
        {categories.length === 0 ? (
          <p className="text-sm opacity-70">{t.noCategories}</p>
        ) : (
          <ul className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-5">
            {categories.map((c) => (
              <li key={c.id} className="rounded-xl border bg-white p-4 text-sm font-medium">
                {lang === 'en' ? c.name_en : c.name_fr}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  )
}
