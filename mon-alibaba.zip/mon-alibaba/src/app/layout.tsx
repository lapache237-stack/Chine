import './globals.css'
import type { Metadata } from 'next'
import Header from '@/components/Header'
import { getPrefs } from '@/lib/prefs'

export const metadata: Metadata = {
  title: 'Mon Alibaba',
  description: 'Le commerce sans frontières / Commerce without borders',
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const { lang } = await getPrefs()
  return (
    <html lang={lang}>
      <body className="min-h-screen bg-gray-50 text-navy">
        <Header />
        <main className="mx-auto max-w-6xl px-4 py-8">{children}</main>
      </body>
    </html>
  )
}
