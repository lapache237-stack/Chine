-- MON ALIBABA - Phase 1 : fondations (profils, rôles, pays, devises, catégories, boutiques, produits)
-- À exécuter dans Supabase > SQL Editor. NON TESTÉ : lisez les erreurs éventuelles et renvoyez-les.

create extension if not exists pgcrypto;
create type public.user_role as enum ('buyer','seller','admin');

-- Données de référence
create table public.countries (
  code char(2) primary key, name_fr text not null, name_en text not null, active boolean not null default true);
create table public.currencies (
  code char(3) primary key, name text not null, symbol text, active boolean not null default true);
create table public.exchange_rates (
  id bigint generated always as identity primary key,
  base char(3) not null references public.currencies(code),
  quote char(3) not null references public.currencies(code),
  rate numeric(18,8) not null check (rate > 0),
  fetched_at timestamptz not null default now(),
  unique (base, quote));
create table public.categories (
  id bigint generated always as identity primary key,
  slug text not null unique, name_fr text not null, name_en text not null,
  parent_id bigint references public.categories(id), position int not null default 0);

-- Profils (liés à Supabase Auth)
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text, avatar_url text,
  role public.user_role not null default 'buyer',
  country_code char(2) references public.countries(code),
  language text not null default 'fr' check (language in ('fr','en')),
  currency char(3) references public.currencies(code),
  suspended boolean not null default false,
  created_at timestamptz not null default now());

-- Entreprises, boutiques, produits
create table public.companies (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references public.profiles(id) on delete cascade,
  name text not null, description text, logo_url text,
  country_code char(2) references public.countries(code),
  phone text, email text,
  verification text not null default 'pending' check (verification in ('pending','verified','rejected')),
  created_at timestamptz not null default now());
create table public.stores (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null unique references public.companies(id) on delete cascade,
  slug text not null unique, name text not null, description text, banner_url text,
  active boolean not null default true, created_at timestamptz not null default now());
create table public.products (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  category_id bigint references public.categories(id),
  title text not null, description text,
  price numeric(14,2) not null check (price >= 0),
  currency char(3) not null references public.currencies(code),
  moq int not null default 1 check (moq >= 1),
  stock int not null default 0 check (stock >= 0),
  origin_country char(2) references public.countries(code),
  lead_time_days int check (lead_time_days >= 0),
  status text not null default 'draft' check (status in ('draft','pending','published','rejected')),
  created_at timestamptz not null default now());
create table public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  url text not null, position int not null default 0);
create index on public.products (store_id);
create index on public.products (category_id, status);
create index on public.product_images (product_id);

-- Fonctions utilitaires
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin' and not suspended);
$$;
create or replace function public.owns_store(sid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.stores s join public.companies c on c.id = s.company_id
    where s.id = sid and c.owner_id = auth.uid() and c.verification = 'verified');
$$;

-- Création automatique du profil : toujours acheteur (le rôle n'est jamais lu depuis le client)
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name) values (new.id, new.raw_user_meta_data->>'full_name');
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Seul un admin peut changer un rôle ou une suspension (le SQL Editor, sans auth.uid(), reste autorisé)
create or replace function public.guard_profile() returns trigger language plpgsql as $$
begin
  if auth.uid() is not null and not public.is_admin()
     and (new.role <> old.role or new.suspended <> old.suspended) then
    raise exception 'Modification non autorisée';
  end if;
  return new;
end; $$;
create trigger guard_profile before update on public.profiles
  for each row execute function public.guard_profile();

-- Seul un admin peut changer la vérification d'une entreprise
create or replace function public.guard_company() returns trigger language plpgsql as $$
begin
  if tg_op = 'INSERT' then
    if auth.uid() is not null and not public.is_admin() then new.verification := 'pending'; end if;
  elsif new.verification <> old.verification and auth.uid() is not null and not public.is_admin() then
    raise exception 'Modification non autorisée';
  end if;
  return new;
end; $$;
create trigger guard_company before insert or update on public.companies
  for each row execute function public.guard_company();

-- Entreprise vérifiée => le propriétaire devient vendeur
create or replace function public.company_verified() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.verification = 'verified' and old.verification <> 'verified' then
    update public.profiles set role = 'seller' where id = new.owner_id and role = 'buyer';
  end if;
  return new;
end; $$;
create trigger company_verified after update on public.companies
  for each row execute function public.company_verified();

-- Sécurité RLS
alter table public.countries enable row level security;
alter table public.currencies enable row level security;
alter table public.exchange_rates enable row level security;
alter table public.categories enable row level security;
alter table public.profiles enable row level security;
alter table public.companies enable row level security;
alter table public.stores enable row level security;
alter table public.products enable row level security;
alter table public.product_images enable row level security;

create policy ref_read on public.countries for select using (true);
create policy ref_admin on public.countries for all using (public.is_admin()) with check (public.is_admin());
create policy ref_read on public.currencies for select using (true);
create policy ref_admin on public.currencies for all using (public.is_admin()) with check (public.is_admin());
create policy ref_read on public.exchange_rates for select using (true);
create policy ref_admin on public.exchange_rates for all using (public.is_admin()) with check (public.is_admin());
create policy ref_read on public.categories for select using (true);
create policy ref_admin on public.categories for all using (public.is_admin()) with check (public.is_admin());

create policy profiles_read on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy profiles_update on public.profiles for update
  using (id = auth.uid() or public.is_admin()) with check (id = auth.uid() or public.is_admin());

create policy companies_read on public.companies for select
  using (verification = 'verified' or owner_id = auth.uid() or public.is_admin());
create policy companies_insert on public.companies for insert with check (owner_id = auth.uid());
create policy companies_update on public.companies for update
  using (owner_id = auth.uid() or public.is_admin()) with check (owner_id = auth.uid() or public.is_admin());
create policy companies_admin_delete on public.companies for delete using (public.is_admin());

create policy stores_read on public.stores for select
  using (active or public.owns_store(id) or public.is_admin());
create policy stores_write on public.stores for all
  using (public.owns_store(id) or public.is_admin())
  with check (public.is_admin() or exists (select 1 from public.companies c
    where c.id = company_id and c.owner_id = auth.uid() and c.verification = 'verified'));

create policy products_read on public.products for select
  using (status = 'published' or public.owns_store(store_id) or public.is_admin());
create policy products_insert on public.products for insert
  with check ((public.owns_store(store_id) and status in ('draft','pending')) or public.is_admin());
create policy products_update on public.products for update
  using (public.owns_store(store_id) or public.is_admin())
  with check ((public.owns_store(store_id) and status in ('draft','pending')) or public.is_admin());
create policy products_delete on public.products for delete
  using (public.owns_store(store_id) or public.is_admin());

create policy images_read on public.product_images for select
  using (exists (select 1 from public.products p where p.id = product_id));
create policy images_write on public.product_images for all
  using (exists (select 1 from public.products p where p.id = product_id and (public.owns_store(p.store_id) or public.is_admin())))
  with check (exists (select 1 from public.products p where p.id = product_id and (public.owns_store(p.store_id) or public.is_admin())));

-- Données initiales
insert into public.currencies (code, name, symbol) values
  ('USD','Dollar américain','$'),('EUR','Euro','€'),('XAF','Franc CFA (Afrique centrale)','FCFA'),
  ('XOF','Franc CFA (Afrique de l''Ouest)','FCFA'),('GBP','Livre sterling','£'),('CAD','Dollar canadien','$'),
  ('CNY','Yuan chinois','¥'),('NGN','Naira nigérian','₦'),('GHS','Cedi ghanéen','₵');
insert into public.countries (code, name_fr, name_en) values
  ('CN','Chine','China'),('CM','Cameroun','Cameroon'),('GA','Gabon','Gabon'),('FR','France','France'),
  ('US','États-Unis','United States'),('GB','Royaume-Uni','United Kingdom'),('CA','Canada','Canada'),
  ('NG','Nigeria','Nigeria'),('GH','Ghana','Ghana'),('SN','Sénégal','Senegal'),('CI','Côte d''Ivoire','Ivory Coast');
insert into public.categories (slug, name_fr, name_en, position) values
  ('telephones-electronique','Téléphones et électronique','Phones & electronics',1),
  ('ordinateurs-informatique','Ordinateurs et informatique','Computers & IT',2),
  ('vetements-mode','Vêtements et mode','Clothing & fashion',3),
  ('chaussures-accessoires','Chaussures et accessoires','Shoes & accessories',4),
  ('beaute-cosmetiques','Beauté et cosmétiques','Beauty & cosmetics',5),
  ('maison-decoration','Maison et décoration','Home & decor',6),
  ('equipements-industriels','Équipements industriels','Industrial equipment',7),
  ('machines-outils','Machines et outils','Machinery & tools',8),
  ('pieces-automobiles','Pièces automobiles','Auto parts',9),
  ('agriculture','Agriculture','Agriculture',10),
  ('alimentation-boissons','Alimentation et boissons','Food & beverages',11),
  ('materiel-medical','Matériel médical','Medical supplies',12),
  ('sports-loisirs','Sports et loisirs','Sports & leisure',13),
  ('jouets-enfants','Jouets et produits pour enfants','Toys & kids',14),
  ('materiaux-construction','Matériaux de construction','Construction materials',15);

-- Pour vous nommer administrateur (après votre inscription), exécutez dans le SQL Editor :
-- update public.profiles set role = 'admin' where id = (select id from auth.users where email = 'VOTRE_EMAIL');
