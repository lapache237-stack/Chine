import type { Config } from 'tailwindcss'
const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: { extend: { colors: { brand: '#e8590c', navy: '#0b2545' } } },
  plugins: [],
}
export default config
